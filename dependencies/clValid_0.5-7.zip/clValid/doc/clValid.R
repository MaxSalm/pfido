###################################################
### chunk number 1: prelim
###################################################
library("clValid")


###################################################
### chunk number 2: mouse
###################################################
data(mouse)


###################################################
### chunk number 3: internal
###################################################
express <- mouse[,c("M1","M2","M3","NC1","NC2","NC3")]
rownames(express) <- mouse$ID
intern <- clValid(express, 2:6, clMethods=c("hierarchical","kmeans","pam"),
                  validation="internal")


###################################################
### chunk number 4: 
###################################################
summary(intern)


###################################################
### chunk number 5: internPlot eval=FALSE
###################################################
## op <- par(no.readonly=TRUE)
## par(mfrow=c(2,2),mar=c(4,4,3,1))
## plot(intern, legend=FALSE)
## plot(nClusters(intern),measures(intern,"Dunn")[,,1],type="n",axes=F,
##         xlab="",ylab="")
## legend("center", clusterMethods(intern), col=1:9, lty=1:9, pch=paste(1:9))
## par(op)


###################################################
### chunk number 6: 
###################################################
op <- par(no.readonly=TRUE)
par(mfrow=c(2,2),mar=c(4,4,3,1))
plot(intern, legend=FALSE)
plot(nClusters(intern),measures(intern,"Dunn")[,,1],type="n",axes=F,
        xlab="",ylab="")
legend("center", clusterMethods(intern), col=1:9, lty=1:9, pch=paste(1:9))
par(op)


###################################################
### chunk number 7: stability
###################################################
stab <- clValid(express, 2:6, clMethods=c("hierarchical","kmeans","pam"),
                validation="stability")


###################################################
### chunk number 8: optimal
###################################################
optimalScores(stab)


###################################################
### chunk number 9: stabPlot eval=FALSE
###################################################
## par(mfrow=c(2,2),mar=c(4,4,3,1))
## plot(stab, measure=c("APN","AD","ADM"),legend=FALSE)
## plot(nClusters(stab),measures(stab,"APN")[,,1],type="n",axes=F,
##         xlab="",ylab="")
## legend("center", clusterMethods(stab), col=1:9, lty=1:9, pch=paste(1:9))
## par(op)


###################################################
### chunk number 10: 
###################################################
par(mfrow=c(2,2),mar=c(4,4,3,1))
plot(stab, measure=c("APN","AD","ADM"),legend=FALSE)
plot(nClusters(stab),measures(stab,"APN")[,,1],type="n",axes=F,
        xlab="",ylab="")
legend("center", clusterMethods(stab), col=1:9, lty=1:9, pch=paste(1:9))
par(op)


###################################################
### chunk number 11: biological
###################################################
fc <- tapply(rownames(express),mouse$FC, c)
fc <- fc[!names(fc)%in%c("EST","Unknown")]
bio <- clValid(express, 2:6, clMethods=c("hierarchical","kmeans","pam"),
               validation="biological", annotation=fc)


###################################################
### chunk number 12: bioOptimal
###################################################
optimalScores(bio)


###################################################
### chunk number 13: BHI eval=FALSE
###################################################
## plot(bio, measure="BHI", legendLoc="topleft")


###################################################
### chunk number 14: BSI eval=FALSE
###################################################
## plot(bio, measure="BSI")


###################################################
### chunk number 15: 
###################################################
plot(bio, measure="BHI", legendLoc="topleft")


###################################################
### chunk number 16: 
###################################################
plot(bio, measure="BSI")


###################################################
### chunk number 17: bioc
###################################################
if(require("Biobase") && require("annotate") && require("GO") && require("moe430a")) {
  ## Need to know which affy chip was used in experiment
  ## affymetrix murine genome 430a genechip arrays
  bio2 <- clValid(express, 2:6, clMethods=c("hierarchical","kmeans","pam"),
                  validation="biological",annotation="moe430a",GOcategory="all")
}



###################################################
### chunk number 18: 
###################################################
if(exists("bio2")) optimalScores(bio2)


###################################################
### chunk number 19: BHI2 eval=FALSE
###################################################
## if(exists("bio2")) plot(bio2, measure="BHI", legendLoc="topleft")


###################################################
### chunk number 20: BSI2 eval=FALSE
###################################################
## if(exists("bio2")) plot(bio2, measure="BSI")


###################################################
### chunk number 21: 
###################################################
if(exists("bio2")) plot(bio2, measure="BHI", legendLoc="topleft")


###################################################
### chunk number 22: 
###################################################
if(exists("bio2")) plot(bio2, measure="BSI")


###################################################
### chunk number 23: hierarchical
###################################################
hc <- clusters(bio,"hierarchical")


###################################################
### chunk number 24: hplot eval=FALSE
###################################################
## mfc <- factor(mouse$FC, labels=c("Re","EST","GD","KP","Met","Mis","St","TF","U"))
## tf.gd <- ifelse(mfc%in%c("GD","TF"),levels(mfc)[mfc],"")
## plot(hc, labels=tf.gd, cex=0.7, hang=-1, main="Mouse Cluster Dendrogram")


###################################################
### chunk number 25: 
###################################################
mfc <- factor(mouse$FC, labels=c("Re","EST","GD","KP","Met","Mis","St","TF","U"))
tf.gd <- ifelse(mfc%in%c("GD","TF"),levels(mfc)[mfc],"")
plot(hc, labels=tf.gd, cex=0.7, hang=-1, main="Mouse Cluster Dendrogram")


###################################################
### chunk number 26: twoClusters
###################################################
two <- cutree(hc,2)
xtabs(~mouse$FC + two)


